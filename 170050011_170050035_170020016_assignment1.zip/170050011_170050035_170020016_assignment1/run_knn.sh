python3 main.py --model knn  --preposition run_all  --save_test_outs knn_output --window_size 3
