python3 main.py --model mlp  --preposition run_all  --save_test_outs mlp_output --window_size 3
